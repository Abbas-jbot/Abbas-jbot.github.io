Simple website template for Abbas.

Files:
- index.html
- styles.css
- script.js

How to use:
1. Download and unzip.
2. Edit index.html to change text and images.
3. For contact form, integrate with a backend or a form service.
4. To publish: upload files to GitHub Pages, Netlify, Vercel, or any static host.

Enjoy! — Your assistant
